<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('sign-in', 'Home::signIn');
$routes->get('sign-up', 'RegistrationController::signUp');
$routes->post('sign-up', 'RegistrationController::signUp');








