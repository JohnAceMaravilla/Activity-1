<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In</title>
    <link href="<?= base_url('public/assets/css/sign-in.css'); ?>" rel="stylesheet">
</head>
<body>
    
    <div class="container">

        <div class="form-container">
            <form action="<?= base_url('login') ?>" method="POST">
                <h1>Sign In</h1>
                <div class="infield">
                    <input type="email" name="email" placeholder="Email" required/>
                </div>
                <div class="infield">
                    <input type="password" name="password" placeholder="Password" required/>
                </div>
                <a href="#">Forgot your password?</a>
                <button type="submit">Sign In</button>
            </form>
        </div>

        <div class="right-panel">
            <h1>Welcome Back!</h1>
            <p>Don't have an account?<br>Register Now!</p>
            <button onclick="window.location.href='<?= base_url('sign-up') ?>'">Sign Up</button>
        </div>

    </div>

</body>
</html>
