<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" crossorigin="anonymous" />
    
    <!-- CSS -->
    <link href="<?= base_url('public/assets/css/sign-up.css'); ?>" rel="stylesheet">

</head>
<body>

    <div class="container">
        
        <div class="left-panel">
            <h1>Welcome Back!</h1>
            <p>Already have an account?<br>Sign in Now!</p>
            <button onclick="window.location.href='<?= base_url('sign-in') ?>'">Sign In</button>
        </div>

        <div class="form-container">
            <form id="registrationForm" method="POST">
                <h1>Create Account</h1>
                
                <?php if (session()->getFlashdata('msg_success')): ?>
                    <div class="alert success">
                        <?= session()->getFlashdata('msg_success') ?>
                    </div>
                <?php endif; ?>

                <?php if (session()->getFlashdata('error')): ?>
                    <div class="alert error">
                        <?= session()->getFlashdata('error') ?>
                    </div>
                <?php endif; ?>

                <div class="infield">
                    <input type="text" id="fullname" name="fullname" placeholder="Full Name" required>
                </div>
                <div class="infield">
                    <input type="email" id="email" name="email" placeholder="Email" required>
                </div>
                <div class="infield">
                    <input type="password" id="password" name="password" placeholder="Password" required>
                </div>
                <div class="infield">
                    <input type="password" id="confirm_password" name="confirm_password" placeholder="Confirm Password" required>
                </div>
                <button type="submit">Sign Up</button>
            </form>
        </div>
    </div>

    <script>
        setTimeout(() => {
            let successMsg = document.getElementById("successMessage");
            let errorMsg = document.getElementById("errorMessage");

            if (successMsg) {
                successMsg.style.transition = "opacity 0.5s ease";
                successMsg.style.opacity = "0";
                setTimeout(() => successMsg.style.display = "none", 500);
            }

            if (errorMsg) {
                errorMsg.style.transition = "opacity 0.5s ease";
                errorMsg.style.opacity = "0";
                setTimeout(() => errorMsg.style.display = "none", 500);
            }
        }, 5000); 
    </script>

</body>
</html>
