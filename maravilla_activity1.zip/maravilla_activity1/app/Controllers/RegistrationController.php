<?php

namespace App\Controllers;

use App\Models\RegistrationModel;
use CodeIgniter\Controller;

class RegistrationController extends Controller
{
    public function signUp()
    {
        $session = session();

        $model = new RegistrationModel();

        if ($this->request->is('post')) {
            $post = $this->request->getPost(['fullname', 'email', 'password', 'confirm_password']);

            $post = [
                'fullname' => strip_tags($post['fullname']),
                'email'    => strip_tags($post['email']),
                'password' => $post['password'],
                'confirm_password'  => $post['confirm_password'],
            ];

            $rules = [
                'fullname' => ['label' => 'Full Name', 'rules' => 'required|min_length[2]|max_length[50]'],
                'email'    => ['label' => 'Email', 'rules' => 'required|valid_email|is_unique[users.email]'],
                'password' => ['label' => 'Password', 'rules' => 'required|min_length[6]'],
                'confirm_password'  => ['label' => 'Confirm Password', 'rules' => 'matches[password]'],
            ];

            if (!$this->validate($rules)) {
                $errors = $this->validator->getErrors();
                $firstError = reset($errors);
                return redirect()->back()->withInput()->with('error', $firstError);
            }

            $hashedPassword = password_hash($post['password'], PASSWORD_DEFAULT);

            $data = [
                'fullname'   => $post['fullname'],
                'email'      => $post['email'],
                'password'   => $hashedPassword,
                'created_at' => date('Y-m-d H:i:s'),
            ];

            $model->insert($data);

            $session->setFlashData('msg_success', 'Registration successful!');
        }

        return view('sign-up');
    }
}
