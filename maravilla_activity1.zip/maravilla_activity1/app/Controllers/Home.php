<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function signIn()
    {
        return view('sign-in');
    }
}
